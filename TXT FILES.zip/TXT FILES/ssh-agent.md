# ssh-agent





# help 

```
usage: ssh-agent [-c | -s] [-Dd] [-a bind_address] [-E fingerprint_hash]
                 [-P allowed_providers] [-t life]
       ssh-agent [-a bind_address] [-E fingerprint_hash] [-P allowed_providers]
                 [-t life] command [arg ...]
       ssh-agent [-c | -s] -k
```



## breakdown

```

```
