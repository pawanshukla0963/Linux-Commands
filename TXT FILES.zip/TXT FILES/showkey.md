# showkey





# help 

```
Usage: showkey [option...]

Options:
  -a, --ascii       display the decimal/octal/hex values of the keys.
  -s, --scancodes   display only the raw scan-codes.
  -k, --keycodes    display only the interpreted keycodes (default).
  -h, --help        print this usage message.
  -V, --version     print version number.

Report bugs to authors.
```



## breakdown

```

```
