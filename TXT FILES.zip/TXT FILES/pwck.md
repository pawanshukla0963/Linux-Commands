# pwck





# help 

```
Usage: pwck [options] [passwd [shadow]]

Options:
  -b, --badnames                allow bad names
  -h, --help                    display this help message and exit
  -q, --quiet                   report errors only
  -r, --read-only               display errors and warnings
                                but do not change files
  -R, --root CHROOT_DIR         directory to chroot into
  -s, --sort                    sort entries by UID

```



## breakdown

```

```
